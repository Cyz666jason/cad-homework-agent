# CAD 作业交付说明

共8道题：4幅二维草图、4件三维零件，统一使用毫米。每题独立建模，成果来自题图尺寸及记录的投影、相切和对称关系。

| 编号 | 题目 | 文件目录（相对于项目根目录） | 交付内容 |
|---|---|---|---|
| S1 | 8-1，图8-74 | `deliverables/sketch/8-01/` | DXF、PNG、参数及几何清单 |
| S2 | 8-2，图8-75 | `deliverables/sketch/8-02/` | DXF、PNG、参数及几何清单 |
| S3 | 8-5左，图8-78 | `deliverables/sketch/8-05-A/` | DXF、PNG、参数及几何清单 |
| S4 | 8-5右，图8-78 | `deliverables/sketch/8-05-B/` | DXF、PNG、参数及几何清单 |
| P1 | 9-1(1)，图9-85 | `deliverables/solid/9-01-A/` | STEP、STL、PNG、三幅SVG正投影、参数清单 |
| P2 | 9-1(2)，图9-86 | `deliverables/solid/9-01-B/` | STEP、STL、PNG、三幅SVG正投影、参数清单 |
| P3 | 9-2，图9-87 | `deliverables/solid/9-02/` | STEP、STL、PNG、三幅SVG正投影、参数清单 |
| P4 | 9-3，图9-88 | `deliverables/solid/9-03/` | STEP、STL、PNG、三幅SVG正投影、参数清单 |

`成果预览.pdf`汇总8题的预览。二维DXF包含真实LINE、ARC、CIRCLE图元，轮廓、孔、中心线和尺寸说明分层。三维STEP包含有效实体，STL为封闭三角网格；SVG正投影由实体计算，虚线表示被遮挡的边。

## 查看与使用

- 用支持DXF的CAD软件打开每幅`drawing.dxf`，尺寸单位选mm。
- 用支持STEP的三维CAD软件打开每件`model.step`；STL可用于网格查看或切片。
- 用PNG/PDF快速核对外形，用`reports/dimensions.md`核对尺寸来源和推导。
- STEP、DXF不含SolidWorks或FreeCAD原生特征树；未伪造SLDPRT、SLDDRW或FCStd文件。

## 复跑

在项目根目录执行。首次安装使用已有`scripts/setup.sh`；云环境已安装依赖。

```bash
export XDG_CACHE_HOME=/workspace/.cache/cad-homework-agent
export MPLCONFIGDIR="$XDG_CACHE_HOME/matplotlib"
export PIP_CACHE_DIR="$XDG_CACHE_HOME/pip"
.venv/bin/python -m models.build_all
.venv/bin/python -m pytest -q tests --junitxml=reports/pytest.xml
.venv/bin/python -m models.package_results
```

各题也可以独立运行，例如：

```bash
.venv/bin/python -m models.sketch_8_02
.venv/bin/python -m models.solid_9_03
.venv/bin/python -m models.solid_9_01_b --right-land 9
```

重新生成会更新对应生成文件；请先另存手工修改过的成品。图9-85的立体类型和斜切关系、图9-86右端9mm的采用依据均明确记录在尺寸表，不依赖隐藏的尺寸猜测。

运行打包脚本时，会同时按仓库规则把二维成果复制到`exports/assignment-sketch/`，三维成果复制到`exports/assignment-part/`。`deliverables/`保留供交付和版本管理的副本。压缩包不包含原始教材截图、虚拟环境或缓存。
