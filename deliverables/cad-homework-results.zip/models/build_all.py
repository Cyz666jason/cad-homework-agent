"""生成所有具备完整建模条件的作业；不填补未确认尺寸。"""
from models.sketch_8_01 import build as s1
from models.sketch_8_02 import build as s2
from models.sketch_8_05_a import build as s3
from models.sketch_8_05_b import build as s4
from models.solid_9_01_a import build as p1
from models.solid_9_01_b import build as p2
from models.solid_9_02 import build as p3
from models.solid_9_03 import build as p4


def main():
    for build in (s1,s2,s3,s4,p1,p2,p3,p4):
        manifest=build()
        print(f"{manifest['task']}: {manifest['status']}",flush=True)


if __name__ == "__main__":
    main()
