"""图 8-78 右：三孔叉形轮廓及精确相切过渡。"""
import argparse
import math
from models.cad_common import ROOT, Sketch, arc, circle, line, polar


def transition_center():
    # Intersections: |Q-(0,90)|=35+25; |Q-(50,70)|=20+25.
    d=math.hypot(50,20)
    along=(60**2-45**2+d*d)/(2*d)
    h=math.sqrt(60**2-along**2)
    ux,uy=50/d,-20/d
    return along*ux-h*uy,90+along*uy+h*ux


def geometry():
    qx,qy=transition_center()
    a=math.atan2(qy-90,qx)
    b=math.atan2(qy-70,qx-50)
    p=math.pi
    s=Sketch("8-05-B","8-78 right", {"side_hole_centers": [[-50,70],[50,70]],
        "side_hole_diameter":20,"top_hole_center":[0,90],"top_hole_diameter":30,
        "top_radius":35,"transition_radius":25,"side_radius":20,"lower_fillet_radius":15,
        "leg_outer_width":70,"opening_width":40,"opening_height":50},
        ["左右孔中心间距100，距底边70；中孔比左右孔高20。",
         "外侧竖边x=±35；U口x=±20，顶边y=50。R15下过渡圆心(±50,35)。",
         "R25圆心由与R35、R20的外切方程求交，选上方解；不以像素定尺寸。",
         f"右R25圆心=({qx:.9f},{qy:.9f})；整体高125、宽140为推导值。"])
    s.path("outer", [arc((0,90),35,p/2,a-p/2),
        arc((qx,qy),25,a+p,b-a), arc((50,70),20,b,-p/2-b),
        arc((50,35),15,p/2,p/2), line((35,35),(35,0)), line((35,0),(20,0)),
        line((20,0),(20,50)), line((20,50),(-20,50)), line((-20,50),(-20,0)),
        line((-20,0),(-35,0)), line((-35,0),(-35,35)),
        arc((-50,35),15,0,p/2), arc((-50,70),20,-p/2,-p/2-b),
        arc((-qx,qy),25,-b,b-a), arc((0,90),35,p-a,a-p/2)])
    for i,(c,r) in enumerate((((0,90),15),((-50,70),10),((50,70),10))):
        s.path(f"hole_{i+1}",[circle(c,r)])
        s.cross(c,r+5)
    s.dim("x",-50,50,-30)
    s.dim("x",-35,35,-20)
    s.dim("x",-20,20,-10)
    s.dim("y",0,70,-82)
    s.dim("y",0,50,4)
    s.dim("y",70,90,82)
    s.leader("DIA 30",(15,90),(32,107))
    s.leader("2 x DIA 20",(-40,70),(-43,55))
    s.leader("R35",polar(35,1.0,(0,90)),(40,134))
    s.leader("R25",polar(25,-(a+b)/2,(-qx,qy)),(-79,123))
    s.leader("R20",(70,70),(83,54))
    s.leader("R15",polar(15,3*p/4,(50,35)),(51,29))
    return s


def build(out=ROOT / "deliverables/sketch/8-05-B"):
    return geometry().export(out)


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",default=str(ROOT / "deliverables/sketch/8-05-B"))
    build(p.parse_args().out)
