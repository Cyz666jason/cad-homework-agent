"""图8-74：六重旋转对称盘形轮廓、径向开口槽及双键槽孔。"""
import argparse
import math
from models.cad_common import ROOT, Sketch, arc, circle, line, polar


def geometry():
    p=math.pi
    outer_r, slot_r, slot_center_r, scallop_r = 75, 7.5, 40, 35
    scallop_center_r = 60+scallop_r
    slot_angle=math.asin(slot_r/outer_r)
    delta=math.acos((outer_r**2+scallop_center_r**2-scallop_r**2)/(2*outer_r*scallop_center_r))
    s=Sketch("8-01","8-74", {"outer_diameter":150,"scallop_tangent_diameter":120,
        "slot_center_diameter":80,"center_hole_diameter":40,"slot_width":15,
        "scallop_radius":35,"keyway_height":8,"keyway_total_width":46,"slot_count":6},
        ["按题图六重旋转对称，开口槽每60°均布；端圆心在Ø80圆上，槽端R7.5。",
         "R35凹弧内切到Ø120辅助圆的对应切点，因此圆心半径60+35=95。",
         "凹弧与Ø150外圆求交保留外圆短弧，不额外增加未标注的倒圆。",
         "双键槽对称、总宽46、高8，和Ø40孔精确求交。"])
    entities=[]
    for i in range(6):
        axis=i*p/3
        middle=axis+p/6
        next_axis=axis+p/3
        e=arc((0,0),outer_r,axis+slot_angle,p/6-delta-slot_angle)
        entities.append(e)
        c=polar(scallop_center_r,middle)
        start=math.atan2(e["b"][1]-c[1],e["b"][0]-c[0])
        endpt=polar(outer_r,middle+delta)
        end=math.atan2(endpt[1]-c[1],endpt[0]-c[0])
        entities.append(arc(c,scallop_r,start,-((start-end)%(2*p))))
        e=arc((0,0),outer_r,middle+delta,p/6-delta-slot_angle)
        entities.append(e)
        cap_center=polar(slot_center_r,next_axis)
        cap=arc(cap_center,slot_r,next_axis-p/2,-p)
        entities += [line(e["b"],cap["a"]),cap,line(cap["b"],polar(outer_r,next_axis+slot_angle))]
    s.path("outer",entities)
    angle=math.asin(4/20)
    x=math.sqrt(20**2-4**2)
    s.path("keyed_center",[arc((0,0),20,angle,p-2*angle),line((-x,4),(-23,4)),
        line((-23,4),(-23,-4)),line((-23,-4),(-x,-4)),
        arc((0,0),20,p+angle,p-2*angle),line((x,-4),(23,-4)),
        line((23,-4),(23,4)),line((23,4),(x,4))])
    for r in (75,60,40):
        s.guides.append(circle((0,0),r))
    for angle in (0,p/3,2*p/3):
        s.guides.append(line(polar(82,angle),polar(82,angle+p)))
    s.dim("x",-23,23,-88)
    s.dim("y",-4,4,-29,"8")
    s.leader("DIA 150",polar(75,p/3+.12),(76,84))
    s.leader("DIA 120",polar(60,.65),(84,50))
    s.leader("DIA 80",polar(40,.48),(85,27))
    s.leader("DIA 40",polar(20,-.5),(56,-43))
    s.leader("6 x slot width 15",polar(57,2*p/3),(-92,88))
    s.leader("R35",(0,60),(7,91))
    return s


def build(out=ROOT / "deliverables/sketch/8-01"):
    return geometry().export(out)


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",default=str(ROOT / "deliverables/sketch/8-01"))
    build(p.parse_args().out)
