"""图 8-78 左：四重对称、R20 凸弧、R40 凹弧、5×Ø20。"""
import argparse
import math
from models.cad_common import ROOT, Sketch, arc, circle, polar


def geometry():
    a = 60/math.sqrt(2)
    s = Sketch("8-05-A", "8-78 left", {"pitch_diameter": 120, "hole_diameter": 20,
        "hole_count": 5, "lobe_radius": 20, "concave_radius": 40},
        ["四个外孔在Ø120圆上，按题图四重对称位于45°、135°、225°、315°。",
         "外孔圆心坐标(±60/√2,±60/√2)；R20凸弧与对应孔同心。",
         "R40凹弧与相邻R20凸弧外切，凹弧圆心在坐标轴±60√2处。"])
    p=math.pi
    s.path("outer", [arc((0,2*a),40,-p/4,-p/2), arc((-a,a),20,p/4,p),
        arc((-2*a,0),40,p/4,-p/2), arc((-a,-a),20,3*p/4,p),
        arc((0,-2*a),40,3*p/4,-p/2), arc((a,-a),20,5*p/4,p),
        arc((2*a,0),40,5*p/4,-p/2), arc((a,a),20,7*p/4,p)])
    centers=[(0,0),(-a,a),(-a,-a),(a,-a),(a,a)]
    for i,c in enumerate(centers):
        s.path(f"hole_{i+1}",[circle(c,10)])
        s.cross(c,13)
    s.guides.append(circle((0,0),60))
    s.leader("5 x DIA 20",polar(10,-.4,(a,-a)),(65,-58))
    s.leader("PCD 120",polar(60,.05),(70,16))
    s.leader("R20",polar(20,2.1,(-a,a)),(-71,77))
    s.leader("R40",(0,2*a-40),(0,79))
    return s


def build(out=ROOT / "deliverables/sketch/8-05-A"):
    return geometry().export(out)


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",default=str(ROOT / "deliverables/sketch/8-05-A"))
    build(p.parse_args().out)
