"""图9-87：R68、Ø65/Ø40弯管与偏置Ø50/Ø32竖管。"""
import argparse
import cadquery as cq
from models.cad_common import ROOT, save_solid

PARAMETERS={"bend_centerline_radius":68,"bend_outer_diameter":65,
    "bend_bore_diameter":40,"upright_outer_diameter":50,"upright_bore_diameter":32,
    "upright_axis_from_left":60,"height":110,"bend_angle_degrees":90}


def quarter_torus(radius):
    return cq.Workplane("XY").moveTo(68,0).circle(radius).revolve(90,(0,0),(0,-1))


def geometry():
    elbow=quarter_torus(32.5)
    upright=cq.Workplane("XY").center(60,0).circle(25).extrude(110)
    inner_elbow=quarter_torus(20)
    inner_upright=cq.Workplane("XY",origin=(60,0,-1)).circle(16).extrude(112)
    return elbow.union(upright).cut(inner_elbow).cut(inner_upright).clean()


def build(out=ROOT / "deliverables/solid/9-02"):
    return save_solid(geometry(),out,"9-02","9-87",PARAMETERS,
        ["R68为弯管扫掠中心线半径；截面外径65、内径40；侧口与底口相差90°。",
         "竖管轴线距左端面60，外径50、内孔32，高110。",
         "弯管与竖管先合并外实体，再统一减去两条内腔，保证通道连通。",
         "弯管底端轴线x=68，竖管轴线x=60，偏置8来自已标尺寸之差。",
         "外包络100.5×65×110为推导值。"])


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",default=str(ROOT / "deliverables/solid/9-02"))
    build(p.parse_args().out)
