"""图9-85：正三棱锥被水平面和垂直于主视面的斜面切去一部分。"""
import argparse
import math
import cadquery as cq
from OCP.BRepOffsetAPI import BRepOffsetAPI_ThruSections
from models.cad_common import ROOT, save_solid

PARAMETERS={"base_side":69,"height":76,"cut_upper_height":53,
            "cut_floor_height":15,"cut_floor_x_from_left":48}


def derived():
    side=PARAMETERS["base_side"]
    depth=side*math.sqrt(3)/2
    apex=(side/2,-depth/3,PARAMETERS["height"])
    top_cut_x=apex[0]*PARAMETERS["cut_upper_height"]/apex[2]
    slope=(top_cut_x-48)/(53-15)
    ridge_z=15+(apex[0]-48)/slope
    return {"base_depth":depth,"apex":apex,"cut_upper_x":top_cut_x,
            "cut_dx_dz":slope,"ridge_intersection_z":ridge_z}


def geometry():
    d=derived()
    base=cq.Wire.makePolygon([cq.Vector(0,0,0),cq.Vector(69,0,0),
                              cq.Vector(34.5,-d["base_depth"],0)],close=True)
    loft=BRepOffsetAPI_ThruSections(True,True)
    loft.AddWire(base.wrapped)
    loft.AddVertex(cq.Vertex.makeVertex(*d["apex"]).wrapped)
    loft.Build()
    if not loft.IsDone():
        raise RuntimeError("Pyramid construction failed")
    pyramid=cq.Workplane().newObject([cq.Shape.cast(loft.Shape())])
    x_at_100=48+d["cut_dx_dz"]*(100-15)
    cutter=(cq.Workplane("XZ",origin=(0,100,0))
            .polyline([(-100,15),(48,15),(x_at_100,100),(-100,100)]).close().extrude(200))
    return pyramid.cut(cutter).clean()


def build(out=ROOT / "deliverables/solid/9-01-A"):
    d=derived()
    return save_solid(geometry(),out,"9-01-A","9-85",{**PARAMETERS,**d},
        ["采用题图的正三棱锥投影关系：底面为边长69的等边三角形，锥顶在底面形心铅垂线上。该几何类型来自图形关系，并非新增标注尺寸。",
         "底面深度69√3/2，形心(34.5,-69√3/6)，锥高76；底面尖端朝向主视观察者，俯视投影尖端向下。",
         "上切点在左侧轮廓棱上，高53；相似三角形给出x=34.5×53/76。",
         "水平切面z=15，其右端距左基准48；斜切面通过两已知切点并沿Y方向延伸。",
         "中间棱线交点通过斜切平面与锥棱相交得到，无像素测量或自定角度。"])


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",default=str(ROOT / "deliverables/solid/9-01-A"))
    build(p.parse_args().out)
