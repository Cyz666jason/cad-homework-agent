"""图 8-75：100×80 板，12 个 20×10 长圆槽。"""
import argparse
import math
from models.cad_common import ROOT, Sketch, arc, line


def geometry():
    s = Sketch("8-02", "8-75", {"width": 100, "height": 80, "chamfer": [8, 8],
        "upper_right_concave_radius": 8, "lower_right_radius": 10,
        "slot_width": 10, "slot_center_spacing": 10, "slot_total_length": 20,
        "slot_left_centers_x": [10, 40, 70], "slot_centers_y": [10, 30, 50, 70]},
        ["槽端半径=10/2=5；槽全长=10+2×5=20。",
         "左端圆心距左边10，列节距30；行圆心距下边10，行节距20。",
         "右上角按题图可见内凹四分之一圆切口处理，不替换成凸圆角。"])
    s.path("outer", [line((8,80),(92,80)), arc((100,80),8,math.pi,math.pi/2),
        line((100,72),(100,10)), arc((90,10),10,0,-math.pi/2),
        line((90,0),(0,0)), line((0,0),(0,72)), line((0,72),(8,80))])
    for row, y in enumerate((10,30,50,70)):
        for col, x in enumerate((10,40,70)):
            s.path(f"slot_{row+1}_{col+1}", [line((x,y+5),(x+10,y+5)),
                arc((x+10,y),5,math.pi/2,-math.pi), line((x+10,y-5),(x,y-5)),
                arc((x,y),5,-math.pi/2,-math.pi)])
            s.guides += [line((x-7,y),(x+17,y)), line((x,y-7),(x,y+7)), line((x+10,y-7),(x+10,y+7))]
    s.dim("x",0,100,-15)
    s.dim("y",0,80,-14)
    s.dim("x",10,40,-6)
    s.dim("y",10,30,106)
    s.dim("x",0,8,86,"8")
    s.leader("12 x slot 20 x 10 (R5)",(20,70),(34,94))
    s.leader("R8",(94.343,74.343),(106,85))
    s.leader("R10",(97.071,2.929),(104,-8))
    return s


def build(out=ROOT / "deliverables/sketch/8-02"):
    return geometry().export(out)


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out", default=str(ROOT / "deliverables/sketch/8-02"))
    build(p.parse_args().out)
