"""Analytic CAD geometry, editable DXF export, and geometry-derived previews."""
from __future__ import annotations

import json
import math
from pathlib import Path

import cadquery as cq
import ezdxf
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from mpl_toolkits.mplot3d.art3d import Poly3DCollection
from OCP.BRepLib import BRepLib
from OCP.BRepBndLib import BRepBndLib
from OCP.Bnd import Bnd_Box
from OCP.HLRBRep import HLRBRep_Algo, HLRBRep_HLRToShape
from OCP.HLRAlgo import HLRAlgo_Projector
from OCP.gp import gp_Ax2, gp_Dir, gp_Pnt

ROOT = Path(__file__).resolve().parents[1]
TAU = 2 * math.pi


def polar(r, angle, center=(0.0, 0.0)):
    return (center[0] + r * math.cos(angle), center[1] + r * math.sin(angle))


def line(a, b):
    return {"type": "LINE", "a": tuple(a), "b": tuple(b)}


def arc(c, r, start, sweep):
    return {"type": "ARC", "center": tuple(c), "radius": r,
            "start": start, "sweep": sweep,
            "a": polar(r, start, c), "b": polar(r, start + sweep, c)}


def circle(c, r):
    return {"type": "CIRCLE", "center": tuple(c), "radius": r}


def sample(e, step=math.pi / 100):
    if e["type"] == "LINE":
        return np.array([e["a"], e["b"]])
    start = e.get("start", 0)
    sweep = e.get("sweep", TAU)
    angles = np.linspace(start, start + sweep, max(9, math.ceil(abs(sweep) / step) + 1))
    return np.array([polar(e["radius"], a, e["center"]) for a in angles])


def extrema(e):
    if e["type"] == "LINE":
        return [e["a"], e["b"]]
    if e["type"] == "CIRCLE":
        return [polar(e["radius"], i * math.pi / 2, e["center"]) for i in range(4)]
    points = [e["a"], e["b"]]
    for a in (0, math.pi / 2, math.pi, 3 * math.pi / 2):
        distance = ((a - e["start"]) if e["sweep"] > 0 else (e["start"] - a)) % TAU
        if distance <= abs(e["sweep"]) + 1e-10:
            points.append(polar(e["radius"], a, e["center"]))
    return points


def cad_wire(entities):
    if len(entities) == 1 and entities[0]["type"] == "CIRCLE":
        e = entities[0]
        return cq.Wire.makeCircle(e["radius"], (*e["center"], 0), (0, 0, 1))
    edges = []
    for e in entities:
        a, b = cq.Vector(*e["a"], 0), cq.Vector(*e["b"], 0)
        if e["type"] == "LINE":
            edges.append(cq.Edge.makeLine(a, b))
        else:
            mid = polar(e["radius"], e["start"] + e["sweep"] / 2, e["center"])
            edges.append(cq.Edge.makeThreePointArc(a, cq.Vector(*mid, 0), b))
    return cq.Wire.assembleEdges(edges)


def write_json(path, data):
    path.write_text(json.dumps(data, ensure_ascii=False, indent=2) + "\n", encoding="utf-8")


class Sketch:
    def __init__(self, task, figure, parameters, derivations):
        self.task = task
        self.figure = figure
        self.parameters = parameters
        self.derivations = derivations
        self.paths = {}
        self.guides = []
        self.dimensions = []
        self.leaders = []

    def path(self, name, entities):
        self.paths[name] = entities
        return self

    def cross(self, center, length):
        x, y = center
        self.guides += [line((x-length, y), (x+length, y)), line((x, y-length), (x, y+length))]

    def dim(self, axis, a, b, position, label=None):
        self.dimensions.append((axis, a, b, position, label or f"{abs(b-a):g}"))

    def leader(self, label, point, text):
        self.leaders.append((label, point, text))

    def face(self):
        wires = [cad_wire(entities) for entities in self.paths.values()]
        return cq.Face.makeFromWires(wires[0], wires[1:])

    def export(self, out):
        out = Path(out)
        out.mkdir(parents=True, exist_ok=True)
        face = self.face()
        if not face.isValid():
            raise ValueError(f"Invalid planar face: {self.task}")
        doc = ezdxf.new("R2010")
        doc.units = ezdxf.units.MM
        doc.header["$MEASUREMENT"] = 1
        doc.linetypes.new("CENTER_TASK", dxfattribs={"pattern": [9.5, 6, -1, 1.5, -1]})
        for name, color in (("PROFILE", 7), ("HOLES", 4), ("CENTER", 8), ("DIMENSIONS", 3)):
            doc.layers.new(name, dxfattribs={"color": color, "lineweight": 35 if name in ("PROFILE", "HOLES") else 13})
        doc.layers.get("CENTER").dxf.linetype = "CENTER_TASK"
        msp = doc.modelspace()
        fig, ax = plt.subplots(figsize=(10, 9), layout="constrained")

        def emit(e, layer, color, style="-"):
            attrs = {"layer": layer}
            if e["type"] == "LINE":
                msp.add_line(e["a"], e["b"], dxfattribs=attrs)
            elif e["type"] == "CIRCLE":
                msp.add_circle(e["center"], e["radius"], dxfattribs=attrs)
            else:
                a, b = e["start"], e["start"] + e["sweep"]
                if e["sweep"] < 0:
                    a, b = b, a
                msp.add_arc(e["center"], e["radius"], math.degrees(a) % 360, math.degrees(b) % 360, dxfattribs=attrs)
            pts = sample(e)
            ax.plot(pts[:, 0], pts[:, 1], style, color=color, lw=1.6 if layer != "CENTER" else .65)

        for name, entities in self.paths.items():
            for e in entities:
                emit(e, "PROFILE" if name == "outer" else "HOLES", "#192b40")
        for e in self.guides:
            emit(e, "CENTER", "#939da4", "-.")
        all_points = np.array([p for entities in self.paths.values() for e in entities for p in extrema(e)])
        low, high = all_points.min(axis=0), all_points.max(axis=0)
        span = max(high - low)
        text_height = span / 55
        for axis, a, b, position, label in self.dimensions:
            if axis == "x":
                p1, p2 = (a, position), (b, position)
                label_pos = ((a+b)/2, position + span*.012)
                align = {"ha": "center", "va": "bottom"}
                for x in (a, b):
                    emit(line((x, position-span*.022), (x, position+span*.022)), "DIMENSIONS", "#697b83")
            else:
                p1, p2 = (position, a), (position, b)
                label_pos = (position-span*.012, (a+b)/2)
                align = {"ha": "right", "va": "center", "rotation": 90}
                for y in (a, b):
                    emit(line((position-span*.022, y), (position+span*.022, y)), "DIMENSIONS", "#697b83")
            msp.add_linear_dim(base=p1, p1=p1, p2=p2, angle=0 if axis == "x" else 90,
                               text=label, dimstyle="EZDXF", override={"dimtxt": text_height, "dimasz": text_height*.65,
                               "dimclrd": 3, "dimclre": 3, "dimclrt": 3}, dxfattribs={"layer": "DIMENSIONS"}).render()
            ax.annotate("", p2, p1, arrowprops={"arrowstyle": "<->", "lw": .7, "color": "#697b83"})
            ax.text(*label_pos, label, fontsize=9, color="#425663", **align)
        for label, point, text in self.leaders:
            msp.add_leader([point, text], dxfattribs={"layer": "DIMENSIONS"})
            msp.add_text(label, dxfattribs={"height": text_height, "layer": "DIMENSIONS"}).set_placement(text)
            ax.annotate(label, point, text, fontsize=9, color="#425663",
                        arrowprops={"arrowstyle": "->", "lw": .7, "color": "#697b83"})
        ax.set_aspect("equal")
        framing=[*all_points.tolist(),*[list(t) for _,_,t in self.leaders]]
        for axis,a,b,position,_ in self.dimensions:
            framing.extend([(a,position),(b,position)] if axis=="x" else [(position,a),(position,b)])
        framing=np.array(framing)
        lo,hi=framing.min(axis=0),framing.max(axis=0)
        pad=span*.09
        ax.set_xlim(lo[0]-pad,hi[0]+pad)
        ax.set_ylim(lo[1]-pad,hi[1]+pad)
        ax.set_title(f"{self.task}  |  Fig. {self.figure}  |  mm", fontsize=15, pad=18)
        ax.set_xlabel("x / mm")
        ax.set_ylabel("y / mm")
        ax.grid(alpha=.12)
        fig.savefig(out / "preview.png", dpi=180)
        plt.close(fig)
        doc.saveas(out / "drawing.dxf")
        manifest = {"task": self.task, "figure": self.figure, "status": "complete", "units": "mm",
                    "source": "用户本轮上传题图", "parameters": self.parameters, "derivations": self.derivations,
                    "bounds": [*low.tolist(), *high.tolist()], "area_mm2": face.Area(),
                    "paths": self.paths, "outputs": ["drawing.dxf", "preview.png", "manifest.json"]}
        write_json(out / "manifest.json", manifest)
        return manifest


def orthographic_edges(shape, direction, right):
    """Use OCCT hidden-line removal, with explicit engineering-view screen axes."""
    hlr=HLRBRep_Algo()
    hlr.Add(shape.wrapped)
    hlr.Projector(HLRAlgo_Projector(gp_Ax2(gp_Pnt(),gp_Dir(*direction),gp_Dir(*right))))
    hlr.Update()
    hlr.Hide()
    result=HLRBRep_HLRToShape(hlr)
    groups={"visible":[result.VCompound(),result.Rg1LineVCompound(),result.OutLineVCompound()],
            "hidden":[result.HCompound(),result.OutLineHCompound()]}
    paths={"visible":[],"hidden":[]}
    for kind,compounds in groups.items():
        for compound in compounds:
            if compound.IsNull():
                continue
            BRepLib.BuildCurves3d_s(compound,1e-7)
            for edge in cq.Shape(compound).Edges():
                points,_=edge.sample(.025)
                if edge.IsClosed() and points:
                    points.append(points[0])
                if len(points)>=2:
                    paths[kind].append([[p.x,p.y] for p in points])
    return paths


def save_projection_svg(paths, destination):
    points=np.array([p for items in paths.values() for path in items for p in path])
    low,high=points.min(axis=0),points.max(axis=0)
    pad=max(high-low)*.06
    xmin,ymin=low-pad
    xmax,ymax=high+pad
    header=(f'<svg xmlns="http://www.w3.org/2000/svg" width="720" height="600" '
            f'viewBox="{xmin:.6f} {-ymax:.6f} {xmax-xmin:.6f} {ymax-ymin:.6f}">')
    lines=[header,'<rect x="-1000" y="-1000" width="2000" height="2000" fill="white"/>',
           '<g transform="scale(1,-1)" fill="none" stroke-linecap="round">']
    width=max(high-low)*.0025
    for kind in ("hidden","visible"):
        dash=' stroke-dasharray="1.4,1"' if kind=="hidden" else ''
        color="#9aa4aa" if kind=="hidden" else "#203347"
        for path in paths[kind]:
            commands="M"+" L".join(f"{x:.6f},{y:.6f}" for x,y in path)
            lines.append(f'<path d="{commands}" stroke="{color}" stroke-width="{width:.6f}"{dash}/>')
    lines.extend(["</g>","</svg>"])
    destination.write_text("\n".join(lines)+"\n",encoding="utf-8")


def render_solid(shape, destination, title):
    vertices, triangles = shape.tessellate(.15, .15)
    vertices = np.array([v.toTuple() for v in vertices])
    faces = vertices[np.array(triangles)]
    normals = np.cross(faces[:, 1]-faces[:, 0], faces[:, 2]-faces[:, 0])
    norms = np.linalg.norm(normals, axis=1)
    normals /= np.maximum(norms[:, None], 1e-12)
    light = np.array([-.3, -.6, .74])
    light /= np.linalg.norm(light)
    # OCCT face triangulations may use either winding; avoid false diagonal shading.
    shade = .46 + .48 * np.abs(normals @ light)
    colors = np.c_[shade[:, None] * np.array([.40, .69, .84]), np.ones(len(shade))]
    low, high = vertices.min(axis=0), vertices.max(axis=0)
    center = (low+high)/2
    size = max(high-low)*.6
    fig = plt.figure(figsize=(13, 10), layout="constrained")
    ax = fig.add_subplot(2,2,1,projection="3d")
    ax.add_collection3d(Poly3DCollection(faces,facecolors=colors,edgecolors="none",antialiased=False))
    ax.set(xlim=(center[0]-size,center[0]+size),ylim=(center[1]-size,center[1]+size),
           zlim=(center[2]-size,center[2]+size))
    ax.set_box_aspect((1,1,1))
    ax.set_proj_type("ortho")
    ax.view_init(elev=24,azim=-62)
    ax.set_title("Isometric",fontsize=12)
    ax.set_xlabel("X / mm")
    ax.set_ylabel("Y / mm")
    ax.set_zlabel("Z / mm")
    ax.grid(False)
    views=(("front",(0,-1,0),(1,0,0),"Front","X / mm","Z / mm"),
           ("top",(0,0,1),(1,0,0),"Top","X / mm","Y / mm"),
           ("side",(-1,0,0),(0,-1,0),"Side","-Y / mm","Z / mm"))
    for i,(name,direction,right,label,xlabel,ylabel) in enumerate(views,2):
        paths=orthographic_edges(shape,direction,right)
        save_projection_svg(paths,destination.parent/f"{name}.svg")
        ax=fig.add_subplot(2,2,i)
        for kind in ("hidden","visible"):
            for path in paths[kind]:
                pts=np.array(path)
                ax.plot(pts[:,0],pts[:,1],"--" if kind=="hidden" else "-",
                        color="#a1abb1" if kind=="hidden" else "#203347",
                        lw=.7 if kind=="hidden" else 1.1)
        ax.set_aspect("equal")
        ax.margins(.12)
        ax.set_title(label,fontsize=12)
        ax.set_xlabel(xlabel)
        ax.set_ylabel(ylabel)
        ax.grid(alpha=.12)
    fig.suptitle(title + " | mm | CAD mesh + orthographic projections", fontsize=15)
    fig.savefig(destination, dpi=150)
    plt.close(fig)


def save_solid(part, out, task, figure, parameters, derivations):
    out = Path(out)
    out.mkdir(parents=True, exist_ok=True)
    solids = part.solids().vals()
    if len(solids) != 1 or not solids[0].isValid() or solids[0].Volume() <= 0:
        raise ValueError(f"{task}: invalid or disconnected solid")
    shape = solids[0]
    cq.exporters.export(part, str(out / "model.step"))
    cq.exporters.export(part, str(out / "model.stl"), tolerance=.08, angularTolerance=.12)
    render_solid(shape, out / "preview.png", f"{task} | Fig. {figure}")
    # Mesh caches can expand BoundingBox(); metadata must use the exact B-rep.
    exact_box=Bnd_Box()
    BRepBndLib.AddOptimal_s(shape.wrapped,exact_box,False,False)
    bounds=list(exact_box.Get())
    manifest = {"task": task, "figure": figure, "status": "complete", "units": "mm",
                "source": "用户本轮上传题图", "parameters": parameters, "derivations": derivations,
                "solid_count": 1, "volume_mm3": shape.Volume(1e-8), "volume_integration_tolerance": 1e-8,
                "bounds": bounds,
                "dimensions": [bounds[i+3]-bounds[i] for i in range(3)],
                "outputs": ["model.step", "model.stl", "preview.png", "front.svg", "top.svg", "side.svg", "manifest.json"]}
    write_json(out / "manifest.json", manifest)
    return manifest
