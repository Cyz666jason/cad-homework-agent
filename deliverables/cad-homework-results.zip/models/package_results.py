"""核对最新验证结果，生成中文报告、PDF总览和完整ZIP。"""
import csv
import hashlib
import json
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET
from datetime import datetime
from pathlib import Path
from zoneinfo import ZoneInfo
from zipfile import ZipFile, ZIP_DEFLATED

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.backends.backend_pdf import PdfPages
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
DELIVERABLES=ROOT/"deliverables"
REPORTS=ROOT/"reports"
TASKS=[("S1","8-01","sketch","六个15宽开口槽、双键槽、R35凹弧"),
       ("S2","8-02","sketch","3×4长圆槽、100×80外形、R8/R10角部"),
       ("S3","8-05-A","sketch","5×Ø20、Ø120孔位圆、R20/R40相切"),
       ("S4","8-05-B","sketch","三孔位置、40×50的U口、四组半径过渡"),
       ("P1","9-01-A","solid","正三棱锥投影、53/15切点、48定位及体积"),
       ("P2","9-01-B","solid","六边形60对边距、76/59/24高度、两端9平台"),
       ("P3","9-02","solid","R68弯管、8偏置、两个内腔通畅"),
       ("P4","9-03","solid","60×40×40、R7槽、Ø14孔、8厚斜肋及体积")]


def main():
    suites=ET.parse(REPORTS/"pytest.xml").getroot().findall(".//testsuite")
    totals={key:sum(int(s.attrib.get(key,0)) for s in suites) for key in ("tests","failures","errors","skipped")}
    if totals["tests"]<1 or any(totals[k] for k in ("failures","errors","skipped")):
        raise RuntimeError(f"未获得完整通过的验证记录: {totals}")
    inputs=[p for group in ("sketch","solid") for p in (DELIVERABLES/group).rglob("*") if p.is_file()]
    if (REPORTS/"pytest.xml").stat().st_mtime<max(p.stat().st_mtime for p in inputs):
        raise RuntimeError("生成文件晚于测试记录，请先重新运行测试")
    now=datetime.now(ZoneInfo("Asia/Shanghai")).isoformat(timespec="seconds")
    lines=["# 作业验证报告", "",f"报告时间：{now}（Asia/Shanghai）。", "",
           f"结果：{totals['tests']}项通过；失败0、错误0、跳过0。其中16项为作业检查，1项为原有环境示例测试。", "",
           "| 编号 | 题目 | 状态 | 主要核验 | 面积(mm²) / 体积(mm³) | 输出目录 |",
           "|---|---|---|---|---|---|"]
    for number,task,group,checks in TASKS:
        folder=DELIVERABLES/group/task
        data=json.loads((folder/"manifest.json").read_text())
        for filename in data["outputs"]:
            if not (folder/filename).is_file() or (folder/filename).stat().st_size==0:
                raise RuntimeError(f"输出缺失或为空: {task}/{filename}")
        measure=data.get("volume_mm3",data.get("area_mm2"))
        lines.append(f"| {number} | {task} / 图{data['figure']} | 已生成、核验通过 | {checks} | {measure:.6f} | `deliverables/{group}/{task}/` |")
    lines.extend(["","## 核验范围","",
        "- 四幅DXF可重新读取、单位为mm、审计无错误。每条闭合边界可构造有效平面，孔槽数量与位置逐项检查。",
        "- 四件STEP重新导入后均为1个有效实体。包围尺寸、标注涉及的切点/孔位/壁厚以及清单数据均经检查。",
        "- 图9-85、9-86使用独立截面积分核验体积；图9-88使用组合体解析公式核验体积。",
        "- 图9-87检查两处端口、管壁和内腔通道采样点，避免实心堵孔。",
        "- 四件STL均无开放边和非流形边，网格体积与STEP实体的相对误差小于0.4%。",
        "- 八幅PNG来自实际几何，三维正投影的SVG由OpenCASCADE可见边/隐藏线计算。",
        "- 题图关系的解释和推导详见dimensions.md；验证针对这些公开记录的建模条件。",
        "","## 运行证据","",
        "执行：`.venv/bin/python -m models.build_all`；`.venv/bin/python -m pytest -q tests --junitxml=reports/pytest.xml`。",
        "记录：build_final.log、build_metadata_fix.log、build_volume_fix.log、test_final.log、pytest.xml。第三方Pyparsing有弃用警告，最终测试无失败。",
        "中间新增体积一致性检查曾因CAD库默认积分精度失败，记录于test_volume_diagnosis.log。统一采用1e-8积分精度后通过；未放宽比较阈值。",
        "","## 格式与范围","",
        "交付DXF/STEP/STL、PNG/SVG/PDF预览及可复跑的Python脚本。未生成需要专用软件的SLDPRT、SLDDRW、FCStd原生特征文件。",
        "原始教材截图未加入成果包或提交到公共仓库。当前为本工作区验证结果，未推送GitHub。",""])
    (REPORTS/"verification.md").write_text("\n".join(lines),encoding="utf-8")

    with PdfPages(DELIVERABLES/"成果预览.pdf") as pdf:
        pdf.infodict()["Title"]="CAD Homework - 8 Assignments"
        for _,task,group,_ in TASKS:
            with Image.open(DELIVERABLES/group/task/"preview.png") as image:
                fig,ax=plt.subplots(figsize=(11.7,8.3) if group=="solid" else (8.3,11.7))
                ax.imshow(image)
                ax.axis("off")
                fig.subplots_adjust(0,0,1,1)
                pdf.savefig(fig)
                plt.close(fig)
        if pdf.get_pagecount()!=8:
            raise RuntimeError("PDF页数不正确")

    installed=subprocess.run([sys.executable,"-m","pip","freeze"],check=True,capture_output=True,text=True)
    (REPORTS/"environment_versions.txt").write_text(installed.stdout,encoding="utf-8")
    for group,folder in (("sketch","assignment-sketch"),("solid","assignment-part")):
        shutil.copytree(DELIVERABLES/group,ROOT/"exports"/folder,dirs_exist_ok=True)

    files=[p for p in DELIVERABLES.rglob("*") if p.is_file() and p.suffix!=".zip"]
    files += list((ROOT/"models").glob("*.py"))
    files += list((ROOT/"tests").glob("*.py"))
    files += list((ROOT/"scripts").glob("*.py"))+list((ROOT/"scripts").glob("*.sh"))
    files += [p for p in REPORTS.iterdir() if p.is_file() and p.name!="file_manifest.csv"]
    files += [ROOT/"requirements.txt"]
    files=sorted(set(files))
    with (REPORTS/"file_manifest.csv").open("w",encoding="utf-8",newline="") as stream:
        writer=csv.writer(stream)
        writer.writerow(["path","bytes","sha256"])
        for p in files:
            writer.writerow([p.relative_to(ROOT).as_posix(),p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest()])
    files.append(REPORTS/"file_manifest.csv")
    archive=DELIVERABLES/"CAD_作业_全部成果.zip"
    with ZipFile(archive,"w",compression=ZIP_DEFLATED,compresslevel=9) as output:
        for p in files:
            output.write(p,p.relative_to(ROOT).as_posix())
    with ZipFile(archive) as saved:
        if saved.testzip() is not None:
            raise RuntimeError("ZIP完整性检查失败")
        names=saved.namelist()
        expected={".dxf":4,".step":4,".stl":4,".png":8,".svg":12,".pdf":1}
        for suffix,count in expected.items():
            actual=sum(name.endswith(suffix) for name in names)
            if actual!=count:
                raise RuntimeError(f"{suffix}文件数量错误: {actual} != {count}")
        print(json.dumps({"archive":str(archive),"files":len(names),"bytes":archive.stat().st_size,
                          "tests":totals,"pdf_pages":8,"crc_check":"passed"},ensure_ascii=False,indent=2))


if __name__=="__main__":
    main()
