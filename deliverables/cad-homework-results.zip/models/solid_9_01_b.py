"""图9-86：正六边形底面上的台阶及斜切顶面。"""
import argparse
import math
import cadquery as cq
from models.cad_common import ROOT, save_solid

PARAMETERS={"across_flats":60,"height":76,"left_land":9,
    "left_step_drop":17,"right_height":24,"right_land":9}


def geometry(right_land=9):
    if not 0 < right_land < 51:
        raise ValueError("右端平台宽度必须大于0且小于51")
    half_side=30/math.sqrt(3)
    hexagon=[(0,-half_side),(30,-2*half_side),(60,-half_side),
             (60,half_side),(30,2*half_side),(0,half_side)]
    prism=cq.Workplane("XY").polyline(hexagon).close().extrude(76)
    profile=(cq.Workplane("XZ",origin=(0,100,0))
        .polyline([(0,0),(60,0),(60,24),(60-right_land,24),(9,59),(9,76),(0,76)])
        .close().extrude(200))
    return prism.intersect(profile).clean()


def build(out=ROOT / "deliverables/solid/9-01-B",right_land=9):
    return save_solid(geometry(right_land),out,"9-01-B","9-86",
        {**PARAMETERS,"right_land":right_land},
        ["俯视图按正六边形处理；60为两条平行竖边之间的对边距，不作为边长。",
         "六边形边长=60/√3，前后总长=120/√3。",
         "左平台宽9、顶高76；落差17，因此斜面左端高59。右平台高24。",
         "右端平台宽9按本轮用户对该尺寸的确认采用，并在脚本中作为可调参数。",
         f"斜面水平跨度=60-9-{right_land:g}，高差=59-24=35。"])


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",default=str(ROOT / "deliverables/solid/9-01-B"))
    p.add_argument("--right-land",type=float,default=9)
    a=p.parse_args()
    build(a.out,a.right_land)
