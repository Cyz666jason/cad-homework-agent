"""图9-88：底座、后壁、斜肋、R7 U槽及Ø14通孔。"""
import argparse
import cadquery as cq
from models.cad_common import ROOT, save_solid

PARAMETERS={"width":60,"depth":40,"height":40,"base_thickness":10,
    "back_wall_thickness":10,"rib_width":8,"rib_right_margin":10,"rib_front_height":18,
    "slot_center_x":20,"slot_center_from_top":13,"slot_radius":7,
    "hole_diameter":14,"hole_x_from_left":20,"hole_y_from_front":12}


def geometry():
    base=cq.Workplane("XY").box(60,40,10,centered=False)
    wall=cq.Workplane("XY",origin=(0,30,10)).box(60,10,30,centered=False)
    rib=(cq.Workplane("YZ",origin=(42,0,0)).polyline([(0,10),(30,10),(30,40),(0,18)])
         .close().extrude(8))
    part=base.union(wall).union(rib)
    hole=cq.Workplane("XY",origin=(20,12,-1)).circle(7).extrude(12)
    # XZ workplane normal is -Y. Start behind the back face and cut through it.
    round_slot=cq.Workplane("XZ",origin=(20,41,27)).circle(7).extrude(12)
    open_slot=cq.Workplane("XY",origin=(13,29,27)).box(14,12,14,centered=False)
    return part.cut(hole).cut(round_slot.union(open_slot)).clean()


def build(out=ROOT / "deliverables/solid/9-03"):
    return save_solid(geometry(),out,"9-03","9-88",PARAMETERS,
        ["x沿60宽，y自前向后沿40深，z向上；底板厚10，后壁厚10。",
         "R7开口槽圆心x=20、z=40-13=27，槽底z=20，宽14。",
         "8厚斜肋距右端10，因此x=42..50；顶面自前端18线性升至后壁40。",
         "Ø14孔沿Z贯穿10厚底板，圆心距左边20、距前边12。"])


if __name__ == "__main__":
    p=argparse.ArgumentParser(description=__doc__)
    p.add_argument("--out",default=str(ROOT / "deliverables/solid/9-03"))
    build(p.parse_args().out)
