"""核验实际交付文件及关键尺寸；不用演示板结果替代作业验收。"""
import json
import math
from pathlib import Path
import xml.etree.ElementTree as ET

import cadquery as cq
import ezdxf
import numpy as np
import pytest
from PIL import Image
from vtkmodules.vtkIOGeometry import vtkSTLReader
from vtkmodules.vtkFiltersCore import vtkFeatureEdges, vtkMassProperties

ROOT=Path(__file__).resolve().parents[1]
SKETCH=ROOT/"deliverables/sketch"
SOLID=ROOT/"deliverables/solid"


def dxf(task):
    return ezdxf.readfile(SKETCH/task/"drawing.dxf")


def solid(task):
    part=cq.importers.importStep(str(SOLID/task/"model.step"))
    assert len(part.solids().vals()) == 1
    shape=part.solids().val()
    assert shape.isValid() and shape.Volume()>0
    return shape


def geom_entities(doc, kind):
    return [e for e in doc.modelspace().query(kind) if e.dxf.layer in ("PROFILE","HOLES")]


def close(a,b,atol=1e-6):
    assert np.allclose(a,b,atol=atol,rtol=0)


@pytest.mark.parametrize("task",["8-01","8-02","8-05-A","8-05-B"])
def test_sketch_files_and_closed_boundaries(task):
    doc=dxf(task)
    assert doc.header["$INSUNITS"]==4
    assert not doc.audit().has_errors
    data=json.loads((SKETCH/task/"manifest.json").read_text())
    from models.cad_common import cad_wire
    wires=[]
    for entities in data["paths"].values():
        if len(entities)>1:
            for e,nxt in zip(entities,entities[1:]+entities[:1]):
                close(e["b"],nxt["a"])
        wire=cad_wire(entities)
        assert wire.IsClosed()
        wires.append(wire)
    face=cq.Face.makeFromWires(wires[0],wires[1:])
    assert face.isValid() and face.Area()>0
    expected_count=sum(len(e) for e in data["paths"].values())
    assert len([e for e in doc.modelspace() if e.dxf.layer in ("PROFILE","HOLES")])==expected_count
    with Image.open(SKETCH/task/"preview.png") as image:
        assert min(image.size)>=600
        assert np.asarray(image.convert("RGB")).std()>15


def test_8_01_slots_scallops_and_keyway():
    doc=dxf("8-01")
    arcs=geom_entities(doc,"ARC")
    groups={r:[e for e in arcs if math.isclose(e.dxf.radius,r)] for r in (7.5,20,35,75)}
    assert {r:len(es) for r,es in groups.items()}=={7.5:6,20:2,35:6,75:12}
    slot_angles=[]
    for e in groups[7.5]:
        c=e.dxf.center
        assert math.isclose(math.hypot(c.x,c.y),40,abs_tol=1e-6)
        slot_angles.append(math.atan2(c.y,c.x)%(2*math.pi))
        assert math.isclose((e.dxf.end_angle-e.dxf.start_angle)%360,180,abs_tol=1e-6)
    for a in slot_angles:
        assert abs(a/(math.pi/3)-round(a/(math.pi/3)))<1e-6
    for e in groups[35]:
        c=e.dxf.center
        assert math.isclose(math.hypot(c.x,c.y)-35,60,abs_tol=1e-6)
    keys=[e for e in geom_entities(doc,"LINE") if e.dxf.layer=="HOLES"]
    assert len(keys)==6
    vertical=[e for e in keys if math.isclose(e.dxf.start.x,e.dxf.end.x)]
    assert sorted(round(e.dxf.start.x,6) for e in vertical)==[-23,23]
    assert all(math.isclose(abs(e.dxf.end.y-e.dxf.start.y),8) for e in vertical)


def test_8_02_twelve_slots_and_corner_types():
    doc=dxf("8-02")
    slots=[e for e in geom_entities(doc,"ARC") if e.dxf.layer=="HOLES"]
    assert len(slots)==24
    assert all(math.isclose(e.dxf.radius,5) for e in slots)
    centers={(round(e.dxf.center.x,6),round(e.dxf.center.y,6)) for e in slots}
    assert centers=={(x,y) for x in (10,20,40,50,70,80) for y in (10,30,50,70)}
    corners=[e for e in geom_entities(doc,"ARC") if e.dxf.layer=="PROFILE"]
    assert len(corners)==2
    close([(e.dxf.center.x,e.dxf.center.y,e.dxf.radius) for e in corners],[(100,80,8),(90,10,10)])
    close(json.loads((SKETCH/"8-02/manifest.json").read_text())["bounds"],[0,0,100,80])


def tangent(e, at_end):
    if e["type"]=="LINE":
        v=np.subtract(e["b"],e["a"])
    else:
        angle=e["start"]+(e["sweep"] if at_end else 0)
        v=np.array([-math.sin(angle),math.cos(angle)])*math.copysign(1,e["sweep"])
    return v/np.linalg.norm(v)


def test_8_05_a_five_holes_and_all_tangent_joins():
    doc=dxf("8-05-A")
    holes=geom_entities(doc,"CIRCLE")
    assert len(holes)==5
    assert all(math.isclose(h.dxf.radius,10) for h in holes)
    radii=sorted(math.hypot(h.dxf.center.x,h.dxf.center.y) for h in holes)
    close(radii,[0,60,60,60,60])
    data=json.loads((SKETCH/"8-05-A/manifest.json").read_text())
    outer=data["paths"]["outer"]
    assert sorted(e["radius"] for e in outer)==[20]*4+[40]*4
    for e,nxt in zip(outer,outer[1:]+outer[:1]):
        close(tangent(e,True),tangent(nxt,False))
    a=60/math.sqrt(2)+20
    close(data["bounds"],[-a,-a,a,a])


def test_8_05_b_hole_positions_opening_and_tangent_joins():
    doc=dxf("8-05-B")
    holes=geom_entities(doc,"CIRCLE")
    assert sorted((round(h.dxf.center.x,6),round(h.dxf.center.y,6),round(h.dxf.radius,6)) for h in holes)==[(-50,70,10),(0,90,15),(50,70,10)]
    data=json.loads((SKETCH/"8-05-B/manifest.json").read_text())
    close(data["bounds"],[-70,0,70,125])
    p=data["paths"]["outer"]
    for i in (0,1,2,3,10,11,12,13,14):
        close(tangent(p[i],True),tangent(p[(i+1)%len(p)],False))
    close([p[6]["a"],p[6]["b"],p[7]["b"]],[(20,0),(20,50),(-20,50)])


@pytest.mark.parametrize("task,dimensions",[("9-01-A",(69,69*math.sqrt(3)/2,76)),
    ("9-01-B",(60,120/math.sqrt(3),76)),("9-02",(100.5,65,110)),("9-03",(60,40,40))])
def test_solid_roundtrip_mesh_and_bounds(task,dimensions):
    s=solid(task)
    box=s.BoundingBox()
    close((box.xlen,box.ylen,box.zlen),dimensions,atol=2e-5)
    metadata=json.loads((SOLID/task/"manifest.json").read_text())
    close(metadata["dimensions"],dimensions,atol=2e-5)
    assert math.isclose(metadata["volume_mm3"],s.Volume(1e-8),rel_tol=1e-8)
    reader=vtkSTLReader()
    reader.SetFileName(str(SOLID/task/"model.stl"))
    reader.Update()
    mesh=reader.GetOutput()
    assert mesh.GetNumberOfCells()>10
    bounds=mesh.GetBounds()
    close([bounds[2*i+1]-bounds[2*i] for i in range(3)],dimensions,atol=.03)
    edges=vtkFeatureEdges()
    edges.SetInputData(mesh)
    edges.BoundaryEdgesOn()
    edges.NonManifoldEdgesOn()
    edges.FeatureEdgesOff()
    edges.ManifoldEdgesOff()
    edges.Update()
    assert edges.GetOutput().GetNumberOfCells()==0
    props=vtkMassProperties()
    props.SetInputData(mesh)
    props.Update()
    assert math.isclose(props.GetVolume(),s.Volume(1e-8),rel_tol=.004)
    with Image.open(SOLID/task/"preview.png") as image:
        assert min(image.size)>=900
        assert np.asarray(image.convert("RGB")).std()>15
    for name in ("front","top","side"):
        root=ET.parse(SOLID/task/f"{name}.svg").getroot()
        assert len(root.findall(".//{http://www.w3.org/2000/svg}path"))>=3


def integrate(f,low,high):
    points,weights=np.polynomial.legendre.leggauss(8)
    return (high-low)/2 * sum(w*f((high+low)/2+(high-low)/2*x) for x,w in zip(points,weights))


def test_9_01_a_cut_plane_and_independent_section_volume():
    s=solid("9-01-A")
    width,height=69,76
    x53=34.5*53/76
    k=(x53-48)/38
    ridge_z=15+(34.5-48)/k
    total_area=69**2*math.sqrt(3)/4
    full=lambda z:total_area*(1-z/height)**2
    cut=lambda z:48+k*(z-15)
    right=lambda z:69-34.5*z/76
    left=lambda z:34.5*z/76
    expected=(integrate(full,0,15)+integrate(lambda z:math.sqrt(3)/2*(right(z)-cut(z))**2,15,ridge_z)
        +integrate(lambda z:full(z)-math.sqrt(3)/2*(cut(z)-left(z))**2,ridge_z,53)
        +integrate(full,53,76))
    assert math.isclose(s.Volume(),expected,rel_tol=1e-8)
    vertices=[v.toTuple() for v in s.Vertices()]
    assert any(abs(x-48)<1e-6 and abs(z-15)<1e-6 for x,y,z in vertices)
    assert any(abs(x-x53)<1e-6 and abs(z-53)<1e-6 for x,y,z in vertices)
    assert not s.isInside((20,-10,20))
    assert s.isInside((20,-10,10))


def test_9_01_b_step_slope_and_independent_section_volume():
    s=solid("9-01-B")
    footprint_width=lambda x:2*(30+min(x,60-x))/math.sqrt(3)
    h=lambda x:76 if x<9 else (59-(x-9)*35/42 if x<51 else 24)
    expected=sum(integrate(lambda x:footprint_width(x)*h(x),a,b) for a,b in ((0,9),(9,30),(30,51),(51,60)))
    assert math.isclose(s.Volume(),expected,rel_tol=1e-8)
    for point in ((4,0,75),(10,0,58),(55,0,23)):
        assert s.isInside(point)
    for point in ((10,0,60),(55,0,25),(30,0,42)):
        assert not s.isInside(point)


def test_9_02_open_bores_wall_and_axis_offset():
    s=solid("9-02")
    for point in ((.01,0,68),(60,0,109.9),(68,0,.01),(60,0,40)):
        assert not s.isInside(point),f"Blocked bore at {point}"
    for point in ((.01,25,68),(60,20,109.9),(68,25,.01)):
        assert s.isInside(point),f"Missing tube wall at {point}"
    bore_faces=[f for f in s.Faces() if f.geomType()=="CYLINDER"]
    assert len(bore_faces)>=2


def test_9_03_hole_slot_rib_and_analytic_volume():
    s=solid("9-03")
    expected=60*40*10+60*10*30+8*30*((40+18)/2-10)-14*13*10-math.pi*7**2*10*1.5
    assert math.isclose(s.Volume(),expected,rel_tol=1e-8)
    for point in ((20,12,5),(20,35,35),(20,35,21),(46,15,30)):
        assert not s.isInside(point)
    for point in ((28,12,5),(20,35,19),(10,35,35),(46,15,28)):
        assert s.isInside(point)
